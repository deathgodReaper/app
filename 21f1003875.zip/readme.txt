download all the extensions imported in app.py
open the app.py in a proper ide and run it